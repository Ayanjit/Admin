package app;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*; 


public class LogInForm extends JFrame implements ActionListener{

    private Container c; 
    private JLabel title; 

    private JLabel username; 
    private JTextField tusername; 
    private JLabel password; 
    private JTextField tpassword; 

    private JLabel loginType; 
    private JRadioButton admin; 
    private JRadioButton employee; 
    private ButtonGroup loginTypeGroup; 

    private JButton login;
    private JButton reset; 

    private DataBaseController dbController;


    public LogInForm(){
        //opening dbController to handle db operations
        dbController = new DataBaseController();

        setTitle("Supermarket Management System");
        setBounds(300, 90, 900, 600); 
        setDefaultCloseOperation(EXIT_ON_CLOSE); 
        setResizable(false);

        c = getContentPane(); 
        c.setLayout(null); 

        //title of the page
        title = new JLabel("Supermarket Management System LogIn"); 
        title.setFont(new Font("Arial", Font.PLAIN, 20)); 
        title.setSize(400, 30); 
        title.setLocation(280, 30); 
        c.add(title); 

        //username
        username = new JLabel("UserName"); 
        username.setFont(new Font("Arial", Font.PLAIN, 20)); 
        username.setSize(100, 20); 
        username.setLocation(305, 200); 
        c.add(username); 
  
        tusername = new JTextField(); 
        tusername.setFont(new Font("Arial", Font.PLAIN, 15)); 
        tusername.setSize(190, 20); 
        tusername.setLocation(405, 200); 
        c.add(tusername); 
        
        //password
        password = new JLabel("Password"); 
        password.setFont(new Font("Arial", Font.PLAIN, 20)); 
        password.setSize(100, 20); 
        password.setLocation(305, 250); 
        c.add(password); 
  
        tpassword = new JTextField(); 
        tpassword.setFont(new Font("Arial", Font.PLAIN, 15)); 
        tpassword.setSize(190, 20); 
        tpassword.setLocation(405, 250); 
        c.add(tpassword); 

        //log in type
        loginType = new JLabel("LogIn Type"); 
        loginType.setFont(new Font("Arial", Font.PLAIN, 20)); 
        loginType.setSize(100, 20); 
        loginType.setLocation(320, 300); 
        c.add(loginType); 
  
        admin = new JRadioButton("Admin"); 
        admin.setFont(new Font("Arial", Font.PLAIN, 15)); 
        admin.setSelected(true); 
        admin.setSize(75, 20); 
        admin.setLocation(420, 300); 
        c.add(admin); 
  
        employee = new JRadioButton("Employee"); 
        employee.setFont(new Font("Arial", Font.PLAIN, 15)); 
        employee.setSelected(false); 
        employee.setSize(100, 20); 
        employee.setLocation(495, 300); 
        c.add(employee); 
  
        loginTypeGroup = new ButtonGroup(); 
        loginTypeGroup.add(admin); 
        loginTypeGroup.add(employee); 

        //login btn
        login = new JButton("Login"); 
        login.setFont(new Font("Arial", Font.PLAIN, 15)); 
        login.setSize(100, 20); 
        login.setLocation(340, 350); 
        login.addActionListener(this); 
        c.add(login); 
  
        //reset btn
        reset = new JButton("Reset"); 
        reset.setFont(new Font("Arial", Font.PLAIN, 15)); 
        reset.setSize(100, 20); 
        reset.setLocation(460, 350); 
        reset.addActionListener(this); 
        c.add(reset); 

        setVisible(true); 
    }




    @Override
    public void actionPerformed(ActionEvent e){
        if(e.getSource() == login){
            String usernameText = tusername.getText();
            String passwordText = tpassword.getText();
            if(admin.isSelected()){
                Admin admin = dbController.getAdmin(usernameText, passwordText);
                if(admin != null){
                    AdminMainForm adminMainForm = new AdminMainForm(admin);
                    this.dispose();
                }
                else{
                    if(usernameText == null || usernameText.isEmpty())
                        JOptionPane.showMessageDialog(c, "Please provide Username");
                    else if (passwordText == null || passwordText.isEmpty())
                        JOptionPane.showMessageDialog(c, "Please provide Password");
                    else
                        JOptionPane.showMessageDialog(c, "Wrong Username or Password.");
                }
            }
            else{

            }
        }
        else if(e.getSource() == reset){
            tusername.setText("");
            tpassword.setText("");
            loginTypeGroup.setSelected(admin.getModel(), true);
        }
    }
}