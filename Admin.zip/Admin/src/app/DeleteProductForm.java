package app;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import javax.swing.*; 

public class DeleteProductForm extends JFrame implements ActionListener{

    private Admin admin;

    private Container c; 
    private JLabel title; 

    private JPanel panel;
    private JTable table;
    private JScrollPane scrollPane;

    private JButton delete;
    private JButton back;


    private DataBaseController dbController;

    public DeleteProductForm(Admin admin){
        this.admin = admin;
        //opening dbController to handle db operations
        dbController = new DataBaseController();

        setTitle("Supermarket Management System");
        setBounds(300, 90, 900, 600); 
        setDefaultCloseOperation(EXIT_ON_CLOSE); 
        setResizable(false);

        c = getContentPane(); 
        c.setLayout(null); 

        //title of the page
        title = new JLabel("Products"); 
        title.setFont(new Font("Arial", Font.PLAIN, 20)); 
        title.setSize(200, 30); 
        title.setLocation(380, 30); 
        c.add(title);

        panel = new JPanel();
        panel.setBounds(40,80,800,400);
        //panel.setBackground(Color.gray);  
        c.add(panel);


        String[] columns = {"ID", "Name", "Code", "Quantity", "Price"};
        String[][] data = getProductList();
            
        DefaultTableModel tableModel = new DefaultTableModel(data, columns) {

            @Override
            public boolean isCellEditable(int row, int column) {
               //all cells false
               return false;
            }
        };
        tableModel.fireTableDataChanged();

        table = new JTable();
        table.setModel(tableModel);
        table.setPreferredScrollableViewportSize(new Dimension(780,360));
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        scrollPane=new JScrollPane(table);
        panel.add(scrollPane);


        //delete
        delete = new JButton("Delete"); 
        delete.setFont(new Font("Arial", Font.PLAIN, 18)); 
        delete.setSize(150, 30); 
        delete.setLocation(500, 500); 
        delete.addActionListener(this); 
        c.add(delete);

        //back
        back = new JButton("Back"); 
        back.setFont(new Font("Arial", Font.PLAIN, 18)); 
        back.setSize(150, 30); 
        back.setLocation(700, 500); 
        back.addActionListener(this); 
        c.add(back);

        this.setVisible(true);
    }


    
    

    private String[][] getProductList(){

        ArrayList<Product> products = getProducts();
        if(products == null || products.size()==0){
            return null;
        }

        int size = products.size();
        String[][] productList = new String[size][5];
        for(int i=0; i<size; i++){
            Product product = products.get(i);

            productList[i][0] = product.getProductID();
            productList[i][1] = product.getProductName();
            productList[i][2] = Integer.toString(product.getProductCode());
            productList[i][3] = Integer.toString(product.getProductQuantity());
            productList[i][4] = Double.toString(product.getProductPrice());
        }

        return productList;
    }

    public ArrayList<Product> getProducts(){
        return dbController.getAllProducts();
    }

    private void deleteProducts(){
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        try{
            int SelectedRowIndex = table.getSelectedRow();


            if(SelectedRowIndex == -1){
                JOptionPane.showMessageDialog(c, "Please select a row to delete");
                return;
            }

            try{
                int productID = Integer.parseInt((String)model.getValueAt(SelectedRowIndex, 0));
                if(dbController.deleteProduct(productID)){
                        model.removeRow(SelectedRowIndex);
                }
            }
            catch(Exception e){
                JOptionPane.showMessageDialog(c, "Unable to delete");
                return;
            }
            JOptionPane.showMessageDialog(c, "Deletion is successful");
            }catch(Exception ex)
            {
                JOptionPane.showMessageDialog(null, ex);
            }
    }


    @Override
    public void actionPerformed(ActionEvent e){
        if(e.getSource() == back){
            AdminMainForm adminForm = new AdminMainForm(admin);
            this.dispose();
        }
        else if(e.getSource() == delete){
            deleteProducts();
        }
    }
    
}