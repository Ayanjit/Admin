package app;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*; 

public class AddProductForm extends JFrame implements ActionListener{
    
    private Admin admin;

    private Container c; 
    private JLabel title; 

    private JLabel pName;
    private JTextField tpName;
    private JLabel pCode;
    private JTextField tpCode; 
    private JLabel pQuantity;
    private JTextField tpQuantity;
    private JLabel pPrice;
    private JTextField tpPrice;  

    private JButton add;
    private JButton reset; 
    private JButton back; 


    private DataBaseController dbController;

    public AddProductForm(Admin admin){
        this.admin = admin;
        //opening dbController to handle db operations
        dbController = new DataBaseController();

        setTitle("Supermarket Management System");
        setBounds(300, 90, 900, 600); 
        setDefaultCloseOperation(EXIT_ON_CLOSE); 
        setResizable(false);

        c = getContentPane(); 
        c.setLayout(null); 

        //title of the page
        title = new JLabel("Add New Product"); 
        title.setFont(new Font("Arial", Font.PLAIN, 20)); 
        title.setSize(300, 30); 
        title.setLocation(350, 30); 
        c.add(title);

        //name
        pName = new JLabel("Name"); 
        pName.setFont(new Font("Arial", Font.PLAIN, 20)); 
        pName.setSize(100, 20); 
        pName.setLocation(200, 100); 
        c.add(pName); 
    
        tpName = new JTextField(); 
        tpName.setFont(new Font("Arial", Font.PLAIN, 20)); 
        tpName.setSize(300, 20); 
        tpName.setLocation(350, 100); 
        c.add(tpName); 

        //code
        pCode = new JLabel("Code"); 
        pCode.setFont(new Font("Arial", Font.PLAIN, 20)); 
        pCode.setSize(100, 20); 
        pCode.setLocation(200, 150); 
        c.add(pCode); 
    
        tpCode = new JTextField(); 
        tpCode.setFont(new Font("Arial", Font.PLAIN, 20)); 
        tpCode.setSize(300, 20); 
        tpCode.setLocation(350, 150); 
        c.add(tpCode); 

        //quantity
        pQuantity = new JLabel("Quantity"); 
        pQuantity.setFont(new Font("Arial", Font.PLAIN, 20)); 
        pQuantity.setSize(100, 20); 
        pQuantity.setLocation(200, 200); 
        c.add(pQuantity); 
    
        tpQuantity = new JTextField(); 
        tpQuantity.setFont(new Font("Arial", Font.PLAIN, 20)); 
        tpQuantity.setSize(300, 20); 
        tpQuantity.setLocation(350, 200); 
        c.add(tpQuantity); 


        //price
        pPrice = new JLabel("Price"); 
        pPrice.setFont(new Font("Arial", Font.PLAIN, 20)); 
        pPrice.setSize(100, 20); 
        pPrice.setLocation(200, 250); 
        c.add(pPrice); 
    
        tpPrice = new JTextField(); 
        tpPrice.setFont(new Font("Arial", Font.PLAIN, 20)); 
        tpPrice.setSize(300, 20); 
        tpPrice.setLocation(350, 250); 
        c.add(tpPrice); 

        //add
        add = new JButton("Add"); 
        add.setFont(new Font("Arial", Font.PLAIN, 20)); 
        add.setSize(100, 30); 
        add.setLocation(280, 350); 
        add.addActionListener(this); 
        c.add(add); 

        //reset
        reset = new JButton("Reset"); 
        reset.setFont(new Font("Arial", Font.PLAIN, 20)); 
        reset.setSize(100, 30); 
        reset.setLocation(400, 350); 
        reset.addActionListener(this); 
        c.add(reset); 

        //back
        back = new JButton("Back"); 
        back.setFont(new Font("Arial", Font.PLAIN, 20)); 
        back.setSize(100, 30); 
        back.setLocation(520, 350); 
        back.addActionListener(this); 
        c.add(back); 

        this.setVisible(true);
    }



    @Override
    public void actionPerformed(ActionEvent e){
        if(e.getSource() == add){
            String nameText = tpName.getText();
            int codeText = 0;
            int quantityText = 0; 
            double priceText = 0;
            if(!tpCode.getText().isEmpty()){
                try{
                    codeText = Integer.parseInt(tpCode.getText());
                }
                catch(NumberFormatException ex){
                    JOptionPane.showMessageDialog(c, "Please Numerical Value for Code");
                    tpCode.setText("");
                    return;
                } 
            }
            if(!tpQuantity.getText().isEmpty()){
                try{
                    quantityText = Integer.parseInt(tpQuantity.getText());
                }
                catch(NumberFormatException ex){
                    JOptionPane.showMessageDialog(c, "Please Numerical Value for Quantity");
                    tpQuantity.setText("");
                    return;
                }
            }
            if(!tpPrice.getText().isEmpty()){
                try{
                    priceText =  Double.parseDouble(tpPrice.getText());
                }
                catch(NumberFormatException ex){
                    JOptionPane.showMessageDialog(c, "Please Numerical Value for Price");
                    tpPrice.setText("");
                    return;
                }
            }
            if(nameText.isEmpty()){
                JOptionPane.showMessageDialog(c, "Please provide product name");
            }
            else if(tpCode.getText().isEmpty()){
                JOptionPane.showMessageDialog(c, "Please provide product code");
            }
            else if(tpQuantity.getText().isEmpty()){
                JOptionPane.showMessageDialog(c, "Please provide product quantity");
            }
            else if(tpPrice.getText().isEmpty()){
                JOptionPane.showMessageDialog(c, "Please provide product price");
            }
            else{
                if(dbController.addNewProduct(nameText, codeText, quantityText, priceText)){
                    JOptionPane.showMessageDialog(c, "Product added successfully");
                    AdminMainForm adminForm = new AdminMainForm(admin);
                    this.dispose();
                }
                else{
                    JOptionPane.showMessageDialog(c, "Failed to add product");
                }
            }
        }
        else if(e.getSource() == reset){
            tpName.setText("");
            tpCode.setText("");
            tpPrice.setText("");
            tpQuantity.setText("");
        }
        else if(e.getSource() == back){
            AdminMainForm adminForm = new AdminMainForm(admin);
            this.dispose();
        }
    }
}