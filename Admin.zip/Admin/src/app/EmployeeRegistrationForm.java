package app;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*; 

public class EmployeeRegistrationForm extends JFrame implements ActionListener{
    
    private Admin admin;

    private Container c; 
    private JLabel title; 

    private JLabel firstName;
    private JTextField tFirstName;
    private JLabel lastName;
    private JTextField tLastName;
    private JLabel mobileNumber;
    private JTextField tmobileNumber;
    private JLabel email;
    private JTextField temail;
    private JLabel address;
    private JTextField taddress;
    private JLabel username; 
    private JTextField tusername; 
    private JLabel password; 
    private JTextField tpassword; 

    private JButton submit;
    private JButton reset; 
    private JButton back;

    private DataBaseController dbController;

    public EmployeeRegistrationForm(Admin admin){
        this.admin = admin;
        //opening dbController to handle db operations
        dbController = new DataBaseController();

        setTitle("Supermarket Management System");
        setBounds(300, 90, 900, 600); 
        setDefaultCloseOperation(EXIT_ON_CLOSE); 
        setResizable(false);

        c = getContentPane(); 
        c.setLayout(null); 

        //title of the page
        title = new JLabel("Employee Registration"); 
        title.setFont(new Font("Arial", Font.PLAIN, 20)); 
        title.setSize(300, 30); 
        title.setLocation(300, 30); 
        c.add(title);
        
        //first name
        firstName = new JLabel("First Name"); 
        firstName.setFont(new Font("Arial", Font.PLAIN, 20)); 
        firstName.setSize(100, 20); 
        firstName.setLocation(200, 100); 
        c.add(firstName); 
    
        tFirstName = new JTextField(); 
        tFirstName.setFont(new Font("Arial", Font.PLAIN, 20)); 
        tFirstName.setSize(250, 20); 
        tFirstName.setLocation(350, 100); 
        c.add(tFirstName); 

        //last name
        lastName = new JLabel("Last Name"); 
        lastName.setFont(new Font("Arial", Font.PLAIN, 20)); 
        lastName.setSize(100, 20); 
        lastName.setLocation(200, 150); 
        c.add(lastName); 
    
        tLastName = new JTextField(); 
        tLastName.setFont(new Font("Arial", Font.PLAIN, 20)); 
        tLastName.setSize(250, 20); 
        tLastName.setLocation(350, 150); 
        c.add(tLastName); 

        //mobile number
        mobileNumber = new JLabel("Mobile Number"); 
        mobileNumber.setFont(new Font("Arial", Font.PLAIN, 20)); 
        mobileNumber.setSize(150, 20); 
        mobileNumber.setLocation(200, 200); 
        c.add(mobileNumber); 
    
        tmobileNumber = new JTextField(); 
        tmobileNumber.setFont(new Font("Arial", Font.PLAIN, 20)); 
        tmobileNumber.setSize(250, 20); 
        tmobileNumber.setLocation(350, 200); 
        c.add(tmobileNumber); 

        //email
        email = new JLabel("Email"); 
        email.setFont(new Font("Arial", Font.PLAIN, 20)); 
        email.setSize(150, 20); 
        email.setLocation(200, 250); 
        c.add(email); 
    
        temail = new JTextField(); 
        temail.setFont(new Font("Arial", Font.PLAIN, 20)); 
        temail.setSize(250, 20); 
        temail.setLocation(350, 250); 
        c.add(temail); 

        //address
        address = new JLabel("Address"); 
        address.setFont(new Font("Arial", Font.PLAIN, 20)); 
        address.setSize(100, 20); 
        address.setLocation(200, 300); 
        c.add(address); 
    
        taddress = new JTextField(); 
        taddress.setFont(new Font("Arial", Font.PLAIN, 20)); 
        taddress.setSize(250, 20); 
        taddress.setLocation(350, 300); 
        c.add(taddress); 

        //username
        username = new JLabel("UserName"); 
        username.setFont(new Font("Arial", Font.PLAIN, 20)); 
        username.setSize(100, 20); 
        username.setLocation(200, 350); 
        c.add(username); 
  
        tusername = new JTextField(); 
        tusername.setFont(new Font("Arial", Font.PLAIN, 20)); 
        tusername.setSize(250, 20); 
        tusername.setLocation(350, 350); 
        c.add(tusername); 

        //password
        password = new JLabel("Password"); 
        password.setFont(new Font("Arial", Font.PLAIN, 20)); 
        password.setSize(100, 20); 
        password.setLocation(200, 400); 
        c.add(password); 
  
        tpassword = new JTextField(); 
        tpassword.setFont(new Font("Arial", Font.PLAIN, 20)); 
        tpassword.setSize(250, 20); 
        tpassword.setLocation(350, 400); 
        c.add(tpassword); 

        //submit btn
        submit = new JButton("Sumbit"); 
        submit.setFont(new Font("Arial", Font.PLAIN, 15)); 
        submit.setSize(100, 20); 
        submit.setLocation(240, 450); 
        submit.addActionListener(this); 
        c.add(submit); 

        //reset btn
        reset = new JButton("Reset"); 
        reset.setFont(new Font("Arial", Font.PLAIN, 15)); 
        reset.setSize(100, 20); 
        reset.setLocation(400, 450); 
        reset.addActionListener(this); 
        c.add(reset); 

        //back button 
        back = new JButton("Back"); 
        back.setFont(new Font("Arial", Font.PLAIN, 15)); 
        back.setSize(100, 20); 
        back.setLocation(560, 450); 
        back.addActionListener(this); 
        c.add(back); 

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e){
        if(e.getSource() == submit){
            if(tFirstName.getText() == null || tFirstName.getText().isEmpty()){
                JOptionPane.showMessageDialog(c, "Please provide First Name");
            }
            else if(tLastName.getText() == null || tLastName.getText().isEmpty()){
                JOptionPane.showMessageDialog(c, "Please provide Last Name");
            }
            else if(tmobileNumber.getText() == null || tmobileNumber.getText().isEmpty()){
                JOptionPane.showMessageDialog(c, "Please provide Mobile Number");
            }
            else if(temail.getText() == null || temail.getText().isEmpty()){
                JOptionPane.showMessageDialog(c, "Please provide Email Address");
            }
            else if(taddress.getText() == null || taddress.getText().isEmpty()){
                JOptionPane.showMessageDialog(c, "Please provide Address");
            }
            else if(tusername.getText() == null || tusername.getText().isEmpty()){
                JOptionPane.showMessageDialog(c, "Please provide UserName");
            }
            else if(tpassword.getText() == null || tpassword.getText().isEmpty()){
                JOptionPane.showMessageDialog(c, "Please provide Password");
            }
            else{
                dbController.registerNewEmployee(   tFirstName.getText(),
                                                    tLastName.getText(),
                                                    tmobileNumber.getText(),
                                                    temail.getText(),
                                                    taddress.getText(),
                                                    tusername.getText(),
                                                    tpassword.getText());

                AdminMainForm adminForm = new AdminMainForm(admin);
                this.dispose();
            }
        }
        else if(e.getSource() == back){
            AdminMainForm adminForm = new AdminMainForm(admin);
            this.dispose();
        }
        else if(e.getSource() == reset){
            tFirstName.setText("");
            tLastName.setText("");
            tmobileNumber.setText("");
            temail.setText("");
            taddress.setText("");
            tusername.setText("");
            tpassword.setText("");
        }
    }
}