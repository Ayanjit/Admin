package app;

public class App {
    public static void main(String[] args) throws Exception {
        openForm();
    }

    public static void openForm(){
        LogInForm form = new LogInForm();
    }
}