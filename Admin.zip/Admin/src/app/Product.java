package app;

import java.security.Principal;

public class Product {
    
    private String productID;
    private String productName;
    private int productCode;
    private int productQuantity;
    private double productPrice;

    public String getProductID(){
        return productID;
    }

    public String getProductName(){
        return productName;
    }

    public int getProductCode(){
        return productCode;
    }

    public int getProductQuantity(){
        return productQuantity;
    }

    public double getProductPrice(){
        return productPrice;
    }

    public void setProductID(String id){
        this.productID = id;
    }

    public void setProductName(String name){
        this.productName = name;
    }

    public void setProductCode(int code){
        this.productCode = code;
    }

    public void setProductQuantity(int quantity){
        this.productQuantity = quantity;
    }

    public void setProductPrice(double price){
        this.productPrice = price;
    }
}