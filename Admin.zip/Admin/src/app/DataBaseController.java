package app;

import java.sql.*;
import java.util.ArrayList;

public class DataBaseController {


    public Admin getAdmin(String username, String password){
            try{
                String dbPassword = "1234";
                Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/supermarketdb", "root", dbPassword);
                
                String query = "SELECT * FROM admin where user_name = '"+ username + "' and password ='" + password + "'";
                Statement statement = connection.createStatement();
                ResultSet rs = statement.executeQuery(query);

                while(rs.next()){
                    Admin admin = new Admin();
                    admin.setFirstName(rs.getString("first_name"));
                    admin.setLastName(rs.getString("last_name"));
                    admin.setMobileNumber(rs.getString("mobile_number"));
                    admin.setAddress(rs.getString("address"));
                    admin.setEmail(rs.getString("email_id"));
        
                    return admin;
                }

            }
            catch(Exception e){
                e.printStackTrace();
            }

        return null;
    }


    public Boolean registerNewEmployee(String firstName, String lastName, String mobile, String email, String address, String username, String password){
        try{
            String dbPassword = "1234";
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/supermarketdb", "root", dbPassword);
            
            String query = "INSERT INTO employee values('" + firstName + "','" + lastName + "','" + username + "','" +
            password + "','" + email + "','" + mobile + "','" + address +"')";
            
            Statement statement = connection.createStatement();
            statement.executeUpdate(query);
            
            connection.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return false;
    }

    public Boolean addNewProduct(String name, int code, int quantity, double price){
        try{
            String dbPassword = "1234";
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/supermarketdb", "root", dbPassword);
            
            String query = "INSERT INTO product values(0,'" + name + "'," + Integer.toString(code) + "," + Integer.toString(quantity) + "," + Double.toString(price) + ")";
            Statement statement = connection.createStatement();
            statement.executeUpdate(query);
            
            connection.close();

            return true;
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return false;
    }

    public ArrayList<Product> getAllProducts(){
        try{
            String dbPassword = "1234";
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/supermarketdb", "root", dbPassword);
            
            ArrayList<Product> productList = new ArrayList<>();
            String query = "SELECT * FROM product";
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery(query);

            while(rs.next()){
                Product product = new Product();
                product.setProductID(rs.getString("product_id"));
                product.setProductName(rs.getString("product_name"));
                product.setProductCode(Integer.parseInt(rs.getString("product_code")));
                product.setProductQuantity(Integer.parseInt(rs.getString("product_quantity")));
                product.setProductPrice(Double.parseDouble(rs.getString("product_price")));
            
                productList.add(product);
            }

            return productList;
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }

    public Boolean deleteProduct(int productID){
        try{
            String dbPassword = "1234";
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/supermarketdb", "root", dbPassword);
            
            String query = "DELETE FROM product WHERE product_id = " + Integer.toString(productID);
            Statement statement = connection.createStatement();
            statement.executeUpdate(query);
            
            connection.close();

            return true;
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return false;
    }
}