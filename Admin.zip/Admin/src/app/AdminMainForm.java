package app;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*; 


public class AdminMainForm extends JFrame implements ActionListener{

    private Container c; 
    private JLabel title;

    private Admin admin;

    private JLabel adminUsername; 
    private JButton registerNewEmployee;
    private JButton addNewProduct;
    private JButton showProducts;
    private JButton deleteProduct;
    private JButton signoutBtn;

    public AdminMainForm(Admin admin){
        this.admin = admin;

        setTitle("Supermarket Management System");
        setBounds(300, 90, 900, 600); 
        setDefaultCloseOperation(EXIT_ON_CLOSE); 
        setResizable(false);

        c = getContentPane(); 
        c.setLayout(null); 

        //title of the page
        title = new JLabel("Admin Panel"); 
        title.setFont(new Font("Arial", Font.PLAIN, 20)); 
        title.setSize(200, 30); 
        title.setLocation(380, 30); 
        c.add(title); 

        //current admin username
        //username
        adminUsername = new JLabel("Admin Name : " + admin.getFirstName() + " " + admin.getLastName()); 
        adminUsername.setFont(new Font("Arial", Font.PLAIN, 16)); 
        adminUsername.setSize(300, 20); 
        adminUsername.setLocation(500, 60); 
        c.add(adminUsername); 

        //Register new employee btn
        registerNewEmployee = new JButton("Register New Employee"); 
        registerNewEmployee.setFont(new Font("Arial", Font.PLAIN, 18)); 
        registerNewEmployee.setSize(400, 30); 
        registerNewEmployee.setLocation(250, 100); 
        registerNewEmployee.addActionListener(this); 
        c.add(registerNewEmployee);

        //add new product
        addNewProduct = new JButton("Add New Product"); 
        addNewProduct.setFont(new Font("Arial", Font.PLAIN, 18)); 
        addNewProduct.setSize(400, 30); 
        addNewProduct.setLocation(250, 150); 
        addNewProduct.addActionListener(this); 
        c.add(addNewProduct);

        //show products
        showProducts = new JButton("Show Products"); 
        showProducts.setFont(new Font("Arial", Font.PLAIN, 18)); 
        showProducts.setSize(400, 30); 
        showProducts.setLocation(250, 200); 
        showProducts.addActionListener(this); 
        c.add(showProducts);

        //delete products
        deleteProduct = new JButton("Delete Products"); 
        deleteProduct.setFont(new Font("Arial", Font.PLAIN, 18)); 
        deleteProduct.setSize(400, 30); 
        deleteProduct.setLocation(250, 250); 
        deleteProduct.addActionListener(this); 
        c.add(deleteProduct);


        //log out btn
        signoutBtn = new JButton("Sign Out"); 
        signoutBtn.setFont(new Font("Arial", Font.PLAIN, 18)); 
        signoutBtn.setSize(150, 30); 
        signoutBtn.setLocation(700, 500); 
        signoutBtn.addActionListener(this); 
        c.add(signoutBtn);

        setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e){
        if(e.getSource() == registerNewEmployee){
            EmployeeRegistrationForm employeeRegistrationForm = new EmployeeRegistrationForm(admin);
            this.dispose();
        }
        else if(e.getSource() == addNewProduct){
            AddProductForm form = new AddProductForm(admin);
            this.dispose();
        }
        else if(e.getSource() == showProducts){
            ShowProductForm form = new ShowProductForm(admin);
            this.dispose();
        }
        else if(e.getSource() == deleteProduct){
            DeleteProductForm form = new DeleteProductForm(admin);
            this.dispose();
        }
        else if(e.getSource() == signoutBtn){
            LogInForm loginForm = new LogInForm();
            this.dispose();
        }
    }
}